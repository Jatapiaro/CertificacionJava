/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heaven;

/**
 *
 * @author jacobotapia
 */
public class God extends Heaven{
    
    /*
    * Se demuestra que en una subclase o herencia, podemos acceder
    * a todos menos al atributo privado de la otra clase
    */
    God(){
        System.out.println(
            this.angel1 + " " + this.angel2 + " " + this.angel3 + " " + this.angel4
        );
    }
    
}
