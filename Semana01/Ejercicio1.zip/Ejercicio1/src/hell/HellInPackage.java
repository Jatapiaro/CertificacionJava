/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hell;

/**
 *
 * @author jacobotapia
 * Se demuestra que aunque están en el mismo paquete
 * el elemento privado de hell.soul4 no se puede usar
 */
public class HellInPackage {
    
    Hell hell;
    public HellInPackage(){
        System.out.println(
            hell.soul1 + " " + hell.soul2 + " " + " " + hell.soul3 + hell.soul4);
    }
    
}
